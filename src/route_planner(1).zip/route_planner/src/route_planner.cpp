//
// Created by jalong on 2023/11/28.
//

#include "route_planner.hpp"
#include <robint_msgs/GetMapInfo.h>

namespace route_planner {

RoutePlanner::RoutePlanner(ros::NodeHandle& pnh) {

  // Initialize ros related stuff
  get_plan_srv_ = pnh.advertiseService("get_plan", &RoutePlanner::HandleGetPlan, this);
  current_map_info_sub_ = pnh.subscribe("/map_widger_server/current_map_info", 1,
                                        &RoutePlanner::CurrentMapInfoCallback, this);


  // TODO:: maintain a map container for nav_graph storage
  // TODO:: each map has their own nav_graph

  // Initialize NavGraph
  nav_graph_.reset(new nav_graph::NavGraph);
  std::string yaml_path;
  yaml_path = "/home/jalong/Projects/rmf_traffic_editor/build/sim.building.yaml";

  nav_graph_->BuildGraph(yaml_path);

  std::string map_uuid = nav_graph_->GetMapUUID();

  std::cout << "map_uuid -> " << map_uuid << std::endl;
  auto map_info = QueryMapInfo(map_uuid);
  if (map_info) {
    printf("Set Map Info Success\n");
    nav_graph_->SetMapInfo(*map_info);
  }

}

bool RoutePlanner::HandleGetPlan(robint_msgs::GetPlanRequest& req,
                                 robint_msgs::GetPlanResponse& res) {

  auto start_vertex = nav_graph_->QueryNearestVertex(req.start);
  if (!start_vertex) {
    res.success = false;
    return true;
  }

  auto end_vertex = nav_graph_->QueryNearestVertex(req.goal);
  if (!end_vertex) {
    res.success = false;
    return true;
  }

  auto vertex_path = dijkstra_planner::DijkstraShortestPath(*nav_graph_, *start_vertex, *end_vertex);

  if (vertex_path.empty()) {
    res.success = false;
  } else {
    res.plan = nav_graph_->ConvertToNavMsgPath(vertex_path);
    res.success = true;
  }
  return true;
}

void RoutePlanner::CurrentMapInfoCallback(const robint_msgs::MapInfoConstPtr& msg) {
  current_map_uuid_ = msg->uuid;
}

boost::optional<MapInfo> RoutePlanner::QueryMapInfo(const std::string& map_uuid) {
  std::string service_name = "/map_widget_server/get_map_info";
  while (ros::ok()) {
    if (ros::service::exists(service_name.c_str(), true)) {
      break;
    }
  }

  robint_msgs::GetMapInfo::Request req;
  robint_msgs::GetMapInfo::Response res;
  req.map_uuid = map_uuid;
  if (ros::service::call(service_name, req, res)) {
    if (res.success) {
      MapInfo map_info;
      map_info.map_uuid = map_uuid;
      map_info.origin = res.map_info.origin;
      map_info.width = res.map_info.width;
      map_info.height = res.map_info.height;
      return map_info;
    } else {
      return boost::none;
    }
  }
  return boost::none;
}

}

