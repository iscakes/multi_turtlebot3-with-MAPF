//
// Created by jalong on 2023/11/28.
//

#ifndef SRC_ROBINTROS_ROBINT_NAVIGATION_ROUTE_PLANNER_SRC_ROUTE_PLANNER_H_
#define SRC_ROBINTROS_ROBINT_NAVIGATION_ROUTE_PLANNER_SRC_ROUTE_PLANNER_H_
#include <ros/ros.h>
#include <robint_msgs/GetPlan.h>
#include "nav_graph.hpp"
#include "dijkstra_planner.hpp"

namespace route_planner {

class RoutePlanner {
 public:
  RoutePlanner(ros::NodeHandle& pnh);

 private:
  bool HandleGetPlan(robint_msgs::GetPlanRequest& req,
                     robint_msgs::GetPlanResponse& res);

  void CurrentMapInfoCallback(const robint_msgs::MapInfoConstPtr& msg);

  boost::optional<MapInfo> QueryMapInfo(const std::string& map_uuid);

 private:
  ros::ServiceServer get_plan_srv_;
  ros::Subscriber current_map_info_sub_;

  std::unique_ptr<nav_graph::NavGraph> nav_graph_;
  std::string current_map_uuid_;

};


}
#endif //SRC_ROBINTROS_ROBINT_NAVIGATION_ROUTE_PLANNER_SRC_ROUTE_PLANNER_H_
