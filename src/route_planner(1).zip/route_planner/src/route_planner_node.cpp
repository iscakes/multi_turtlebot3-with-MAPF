//
// Created by jalong on 2023/11/28.
//

#include "route_planner.hpp"

int main(int argc, char** argv) {
  ros::init(argc, argv, "route_planner");

  ros::NodeHandle nh("~");
  route_planner::RoutePlanner rp(nh);

  ros::spin();
  return 0;
}